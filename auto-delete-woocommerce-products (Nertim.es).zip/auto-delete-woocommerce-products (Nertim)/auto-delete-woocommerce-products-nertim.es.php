<?php
/**
 * Plugin Name: Auto Delete WooCommerce Products By Nertim.es
 * Description: Automatically deletes WooCommerce products after a specified time.
 * Version: 1.0.0
 */

// Add the auto-delete function
function auto_delete_products() {
    $days_to_keep = get_option('auto_delete_days_to_keep', 30); // Get the number of days to keep from the options panel
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'date_query' => array(
            array(
                'before' => "$days_to_keep days ago"
            )
        )
    );
 
    $products = get_posts( $args );
 
    foreach( $products as $product ) {
        wp_delete_post( $product->ID, true );
    }
}

// Schedule the auto-delete function
add_action( 'wp', 'schedule_auto_delete' );
function schedule_auto_delete() {
    if ( ! wp_next_scheduled( 'auto_delete_products' ) ) {
        wp_schedule_event( time(), 'daily', 'auto_delete_products' );
    }
}

// Add the settings page
add_action('admin_menu', 'auto_delete_products_add_admin_menu');
add_action('admin_init', 'auto_delete_products_settings_init');
function auto_delete_products_add_admin_menu() {
    add_options_page('Auto Delete Products Settings', 'Auto Delete Products', 'manage_options', 'auto_delete_products', 'auto_delete_products_options_page');
}
function auto_delete_products_settings_init() {
    register_setting('auto_delete_products_options', 'auto_delete_days_to_keep');
    add_settings_section('auto_delete_products_options_section', 'Auto Delete Products Settings', '', 'auto_delete_products_options');
    add_settings_field('auto_delete_days_to_keep_field', 'Days to Keep', 'auto_delete_days_to_keep_field_render', 'auto_delete_products_options', 'auto_delete_products_options_section');
}
function auto_delete_days_to_keep_field_render() {
    $days_to_keep = get_option('auto_delete_days_to_keep', 30);
    echo "<input type='number' name='auto_delete_days_to_keep' value='$days_to_keep' />";
}
function auto_delete_products_options_page() {
?>
    <div class="wrap">
        <h2>Auto Delete Products Settings (nertim.es)</h2>
        <form method="post" action="options.php">
            <?php
            settings_fields('auto_delete_products_options');
            do_settings_sections('auto_delete_products_options');
            submit_button();
            ?>
        </form>
    </div>
<?php
}
